Public Class frmCool
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnTest1 As System.Windows.Forms.Button
    Friend WithEvents btnTest2 As System.Windows.Forms.Button
    Friend WithEvents btnTest3 As System.Windows.Forms.Button
    Friend WithEvents btnTest4 As System.Windows.Forms.Button
    Friend WithEvents btnTest5 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnTest1 = New System.Windows.Forms.Button()
        Me.btnTest2 = New System.Windows.Forms.Button()
        Me.btnTest3 = New System.Windows.Forms.Button()
        Me.btnTest4 = New System.Windows.Forms.Button()
        Me.btnTest5 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnTest1
        '
        Me.btnTest1.Location = New System.Drawing.Point(16, 16)
        Me.btnTest1.Name = "btnTest1"
        Me.btnTest1.Size = New System.Drawing.Size(120, 32)
        Me.btnTest1.TabIndex = 0
        Me.btnTest1.Text = "Message Box Test 1"
        '
        'btnTest2
        '
        Me.btnTest2.Location = New System.Drawing.Point(152, 16)
        Me.btnTest2.Name = "btnTest2"
        Me.btnTest2.Size = New System.Drawing.Size(120, 32)
        Me.btnTest2.TabIndex = 1
        Me.btnTest2.Text = "Message Box Test 2"
        '
        'btnTest3
        '
        Me.btnTest3.Location = New System.Drawing.Point(288, 16)
        Me.btnTest3.Name = "btnTest3"
        Me.btnTest3.Size = New System.Drawing.Size(120, 32)
        Me.btnTest3.TabIndex = 2
        Me.btnTest3.Text = "Message Box Test 3"
        '
        'btnTest4
        '
        Me.btnTest4.Location = New System.Drawing.Point(16, 64)
        Me.btnTest4.Name = "btnTest4"
        Me.btnTest4.Size = New System.Drawing.Size(120, 32)
        Me.btnTest4.TabIndex = 3
        Me.btnTest4.Text = "Process.Start Test"
        '
        'btnTest5
        '
        Me.btnTest5.Location = New System.Drawing.Point(152, 64)
        Me.btnTest5.Name = "btnTest5"
        Me.btnTest5.Size = New System.Drawing.Size(256, 32)
        Me.btnTest5.TabIndex = 4
        Me.btnTest5.Text = "Quick + Easy Lifesavers"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 120)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(392, 24)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Also see: Lotto program and File Writer"
        '
        'frmCool
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(424, 157)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.btnTest5, Me.btnTest4, Me.btnTest3, Me.btnTest2, Me.btnTest1})
        Me.Name = "frmCool"
        Me.Text = "Exploring the .NET Framework: The cool stuff"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnTest1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest1.Click
        MessageBox.Show("Continue?", "KarlOS", _
            MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)
    End Sub

    Private Sub btnTest2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest2.Click
        If MessageBox.Show("Continue?", "KarlOS", MessageBoxButtons.YesNoCancel, _
            MessageBoxIcon.Question) = DialogResult.Cancel Then
            MessageBox.Show("Operation aborted!")
        End If
    End Sub

    Private Sub btnTest3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest3.Click
        Dim MyResult As DialogResult

        MyResult = MessageBox.Show("Continue?", "KarlOS", _
        MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)

        If MyResult = DialogResult.Cancel Then MessageBox.Show("Operation aborted!")

        If MyResult = DialogResult.Yes Then MessageBox.Show("Operation accepted!")

    End Sub

    Private Sub btnTest4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest4.Click
        If MessageBox.Show("Do you want to open the site?", "KarlMoore.com", _
            MessageBoxButtons.YesNo) = DialogResult.Yes Then
            Process.Start("http://www.karlmoore.com/")
        End If
    End Sub

    Private Sub btnTest5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest5.Click
        Dim MyVariable As String
        MyVariable = InputBox("Enter something,anything:")
        MessageBox.Show("Is your entry numeric?" & IsNumeric(MyVariable))
        MessageBox.Show("Is your entry a date?" & IsDate(MyVariable))
        MessageBox.Show("The Val of your entry is:" & Val(MyVariable))
    End Sub
End Class

Public Class Calculator
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu As System.Windows.Forms.MainMenu
    Friend WithEvents btnLogout As System.Windows.Forms.Button
    Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileNew As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileOpen As System.Windows.Forms.MenuItem
    Friend WithEvents mnuSep1 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileClose As System.Windows.Forms.MenuItem
    Friend WithEvents txtNum1_1 As System.Windows.Forms.TextBox
    Friend WithEvents txtNum1_2 As System.Windows.Forms.TextBox
    Friend WithEvents txtNum2_2 As System.Windows.Forms.TextBox
    Friend WithEvents txtNum2_1 As System.Windows.Forms.TextBox
    Friend WithEvents txtNum3_2 As System.Windows.Forms.TextBox
    Friend WithEvents txtNum3_1 As System.Windows.Forms.TextBox
    Friend WithEvents txtNum4_2 As System.Windows.Forms.TextBox
    Friend WithEvents txtNum4_1 As System.Windows.Forms.TextBox
    Friend WithEvents btnAdd1 As System.Windows.Forms.Button
    Friend WithEvents btnAdd2 As System.Windows.Forms.Button
    Friend WithEvents btnAdd3 As System.Windows.Forms.Button
    Friend WithEvents btnAdd4 As System.Windows.Forms.Button
    Friend WithEvents lblResult1 As System.Windows.Forms.Label
    Friend WithEvents lblResult2 As System.Windows.Forms.Label
    Friend WithEvents lblResult3 As System.Windows.Forms.Label
    Friend WithEvents lblResult4 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu = New System.Windows.Forms.MainMenu()
        Me.mnuFile = New System.Windows.Forms.MenuItem()
        Me.mnuFileNew = New System.Windows.Forms.MenuItem()
        Me.mnuFileOpen = New System.Windows.Forms.MenuItem()
        Me.mnuSep1 = New System.Windows.Forms.MenuItem()
        Me.mnuFileClose = New System.Windows.Forms.MenuItem()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.txtNum1_1 = New System.Windows.Forms.TextBox()
        Me.txtNum1_2 = New System.Windows.Forms.TextBox()
        Me.txtNum2_2 = New System.Windows.Forms.TextBox()
        Me.txtNum2_1 = New System.Windows.Forms.TextBox()
        Me.txtNum3_2 = New System.Windows.Forms.TextBox()
        Me.txtNum3_1 = New System.Windows.Forms.TextBox()
        Me.txtNum4_2 = New System.Windows.Forms.TextBox()
        Me.txtNum4_1 = New System.Windows.Forms.TextBox()
        Me.btnAdd1 = New System.Windows.Forms.Button()
        Me.btnAdd2 = New System.Windows.Forms.Button()
        Me.btnAdd3 = New System.Windows.Forms.Button()
        Me.btnAdd4 = New System.Windows.Forms.Button()
        Me.lblResult1 = New System.Windows.Forms.Label()
        Me.lblResult2 = New System.Windows.Forms.Label()
        Me.lblResult3 = New System.Windows.Forms.Label()
        Me.lblResult4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'mainMenu
        '
        Me.mainMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile})
        '
        'mnuFile
        '
        Me.mnuFile.Index = 0
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFileNew, Me.mnuFileOpen, Me.mnuSep1, Me.mnuFileClose})
        Me.mnuFile.Text = "&File"
        '
        'mnuFileNew
        '
        Me.mnuFileNew.Index = 0
        Me.mnuFileNew.Text = "&New"
        '
        'mnuFileOpen
        '
        Me.mnuFileOpen.Index = 1
        Me.mnuFileOpen.Text = "&Open"
        '
        'mnuSep1
        '
        Me.mnuSep1.Index = 2
        Me.mnuSep1.Text = "-"
        '
        'mnuFileClose
        '
        Me.mnuFileClose.Index = 3
        Me.mnuFileClose.Text = "&Close"
        '
        'btnLogout
        '
        Me.btnLogout.Location = New System.Drawing.Point(8, 224)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(80, 24)
        Me.btnLogout.TabIndex = 0
        Me.btnLogout.Text = "Logout"
        '
        'txtNum1_1
        '
        Me.txtNum1_1.Location = New System.Drawing.Point(40, 16)
        Me.txtNum1_1.Name = "txtNum1_1"
        Me.txtNum1_1.Size = New System.Drawing.Size(48, 20)
        Me.txtNum1_1.TabIndex = 1
        Me.txtNum1_1.Text = ""
        '
        'txtNum1_2
        '
        Me.txtNum1_2.Location = New System.Drawing.Point(96, 16)
        Me.txtNum1_2.Name = "txtNum1_2"
        Me.txtNum1_2.Size = New System.Drawing.Size(48, 20)
        Me.txtNum1_2.TabIndex = 2
        Me.txtNum1_2.Text = ""
        '
        'txtNum2_2
        '
        Me.txtNum2_2.Location = New System.Drawing.Point(240, 16)
        Me.txtNum2_2.Name = "txtNum2_2"
        Me.txtNum2_2.Size = New System.Drawing.Size(48, 20)
        Me.txtNum2_2.TabIndex = 4
        Me.txtNum2_2.Text = ""
        '
        'txtNum2_1
        '
        Me.txtNum2_1.Location = New System.Drawing.Point(184, 16)
        Me.txtNum2_1.Name = "txtNum2_1"
        Me.txtNum2_1.Size = New System.Drawing.Size(48, 20)
        Me.txtNum2_1.TabIndex = 3
        Me.txtNum2_1.Text = ""
        '
        'txtNum3_2
        '
        Me.txtNum3_2.Location = New System.Drawing.Point(96, 120)
        Me.txtNum3_2.Name = "txtNum3_2"
        Me.txtNum3_2.Size = New System.Drawing.Size(48, 20)
        Me.txtNum3_2.TabIndex = 6
        Me.txtNum3_2.Text = ""
        '
        'txtNum3_1
        '
        Me.txtNum3_1.Location = New System.Drawing.Point(40, 120)
        Me.txtNum3_1.Name = "txtNum3_1"
        Me.txtNum3_1.Size = New System.Drawing.Size(48, 20)
        Me.txtNum3_1.TabIndex = 5
        Me.txtNum3_1.Text = ""
        '
        'txtNum4_2
        '
        Me.txtNum4_2.Location = New System.Drawing.Point(240, 120)
        Me.txtNum4_2.Name = "txtNum4_2"
        Me.txtNum4_2.Size = New System.Drawing.Size(48, 20)
        Me.txtNum4_2.TabIndex = 8
        Me.txtNum4_2.Text = ""
        '
        'txtNum4_1
        '
        Me.txtNum4_1.Location = New System.Drawing.Point(184, 120)
        Me.txtNum4_1.Name = "txtNum4_1"
        Me.txtNum4_1.Size = New System.Drawing.Size(48, 20)
        Me.txtNum4_1.TabIndex = 7
        Me.txtNum4_1.Text = ""
        '
        'btnAdd1
        '
        Me.btnAdd1.Location = New System.Drawing.Point(40, 48)
        Me.btnAdd1.Name = "btnAdd1"
        Me.btnAdd1.Size = New System.Drawing.Size(104, 16)
        Me.btnAdd1.TabIndex = 9
        Me.btnAdd1.Text = "="
        '
        'btnAdd2
        '
        Me.btnAdd2.Location = New System.Drawing.Point(184, 48)
        Me.btnAdd2.Name = "btnAdd2"
        Me.btnAdd2.Size = New System.Drawing.Size(104, 16)
        Me.btnAdd2.TabIndex = 10
        Me.btnAdd2.Text = "="
        '
        'btnAdd3
        '
        Me.btnAdd3.Location = New System.Drawing.Point(40, 152)
        Me.btnAdd3.Name = "btnAdd3"
        Me.btnAdd3.Size = New System.Drawing.Size(104, 16)
        Me.btnAdd3.TabIndex = 11
        Me.btnAdd3.Text = "="
        '
        'btnAdd4
        '
        Me.btnAdd4.Location = New System.Drawing.Point(184, 152)
        Me.btnAdd4.Name = "btnAdd4"
        Me.btnAdd4.Size = New System.Drawing.Size(104, 16)
        Me.btnAdd4.TabIndex = 12
        Me.btnAdd4.Text = "="
        '
        'lblResult1
        '
        Me.lblResult1.Location = New System.Drawing.Point(40, 80)
        Me.lblResult1.Name = "lblResult1"
        Me.lblResult1.Size = New System.Drawing.Size(104, 16)
        Me.lblResult1.TabIndex = 13
        Me.lblResult1.Text = "Label1"
        '
        'lblResult2
        '
        Me.lblResult2.Location = New System.Drawing.Point(184, 80)
        Me.lblResult2.Name = "lblResult2"
        Me.lblResult2.Size = New System.Drawing.Size(104, 16)
        Me.lblResult2.TabIndex = 14
        Me.lblResult2.Text = "Label2"
        '
        'lblResult3
        '
        Me.lblResult3.Location = New System.Drawing.Point(40, 184)
        Me.lblResult3.Name = "lblResult3"
        Me.lblResult3.Size = New System.Drawing.Size(104, 16)
        Me.lblResult3.TabIndex = 15
        Me.lblResult3.Text = "Label3"
        '
        'lblResult4
        '
        Me.lblResult4.Location = New System.Drawing.Point(184, 184)
        Me.lblResult4.Name = "lblResult4"
        Me.lblResult4.Size = New System.Drawing.Size(104, 16)
        Me.lblResult4.TabIndex = 16
        Me.lblResult4.Text = "Label4"
        '
        'Calculator
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(320, 257)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblResult4, Me.lblResult3, Me.lblResult2, Me.lblResult1, Me.btnAdd4, Me.btnAdd3, Me.btnAdd2, Me.btnAdd1, Me.txtNum4_2, Me.txtNum4_1, Me.txtNum3_2, Me.txtNum3_1, Me.txtNum2_2, Me.txtNum2_1, Me.txtNum1_2, Me.txtNum1_1, Me.btnLogout})
        Me.Menu = Me.mainMenu
        Me.Name = "Calculator"
        Me.Text = "Calculator"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Sub Goodbye()
        MessageBox.Show("Thank you for using F2K and " & _
            "taking my bank balance to new heights!")
        Me.Close()
    End Sub

    Private Sub btnLogout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogout.Click
        Goodbye()
    End Sub

    Private Sub mnuFileClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileClose.Click
        Goodbye()
    End Sub

    Private Sub btnAdd1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd1.Click
        lblResult1.Text = Add(txtNum1_1.Text, txtNum1_2.Text)
    End Sub

    Private Sub btnAdd2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd2.Click
        lblResult2.Text = Add(txtNum2_1.Text, txtNum2_2.Text)
    End Sub

    Private Sub btnAdd3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd3.Click
        lblResult3.Text = Add(txtNum3_1.Text, txtNum3_2.Text)
    End Sub

    Private Sub btnAdd4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd4.Click
        lblResult4.Text = Add(txtNum4_1.Text, txtNum4_2.Text)
    End Sub
End Class

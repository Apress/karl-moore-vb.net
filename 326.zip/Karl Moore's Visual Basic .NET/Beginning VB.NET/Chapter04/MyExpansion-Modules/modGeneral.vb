Module modGeneral


    Public Function Add(ByVal Number1 As Short, ByVal Number2 As Short) As Short
        Add = Number1 + Number2
    End Function


End Module

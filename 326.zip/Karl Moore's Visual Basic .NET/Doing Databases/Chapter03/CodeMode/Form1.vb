Public Class Form1
    Inherits System.Windows.Forms.Form

    ' Change the following objConnection connection string
    ' to point to your local copy of Surgery.mdb

    Dim objConnection As New OleDb.OleDbConnection( _
        "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Karl Moore's Visual Basic .NET\Doing Databases\Surgery.mdb")
    Dim objOwnerDA As New OleDb.OleDbDataAdapter("Select *from Owners", _
        objConnection)
    Dim objOwnerCB As New OleDb.OleDbCommandBuilder(objOwnerDA)
    Dim objDataSet As New DataSet()

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents grpLine As System.Windows.Forms.GroupBox
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents cboOwners As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblOwnerID As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents btnRetrieve As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.grpLine = New System.Windows.Forms.GroupBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.cboOwners = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblOwnerID = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.btnRetrieve = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'grpLine
        '
        Me.grpLine.Location = New System.Drawing.Point(8, 40)
        Me.grpLine.Name = "grpLine"
        Me.grpLine.Size = New System.Drawing.Size(424, 8)
        Me.grpLine.TabIndex = 0
        Me.grpLine.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.Font = New System.Drawing.Font("Tahoma", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(8, 8)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(344, 32)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "Supercool Surgery, Inc."
        '
        'cboOwners
        '
        Me.cboOwners.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOwners.Location = New System.Drawing.Point(320, 16)
        Me.cboOwners.Name = "cboOwners"
        Me.cboOwners.Size = New System.Drawing.Size(112, 21)
        Me.cboOwners.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(96, 80)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 16)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Owner ID:"
        '
        'lblOwnerID
        '
        Me.lblOwnerID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOwnerID.Location = New System.Drawing.Point(184, 80)
        Me.lblOwnerID.Name = "lblOwnerID"
        Me.lblOwnerID.Size = New System.Drawing.Size(64, 16)
        Me.lblOwnerID.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(96, 112)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 16)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Name:"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(96, 144)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 16)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Address:"
        '
        'txtName
        '
        Me.txtName.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(176, 112)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(128, 21)
        Me.txtName.TabIndex = 7
        Me.txtName.Text = ""
        '
        'txtAddress
        '
        Me.txtAddress.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddress.Location = New System.Drawing.Point(176, 144)
        Me.txtAddress.Multiline = True
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(176, 56)
        Me.txtAddress.TabIndex = 8
        Me.txtAddress.Text = ""
        '
        'btnRetrieve
        '
        Me.btnRetrieve.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRetrieve.Image = CType(resources.GetObject("btnRetrieve.Image"), System.Drawing.Bitmap)
        Me.btnRetrieve.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnRetrieve.Location = New System.Drawing.Point(16, 232)
        Me.btnRetrieve.Name = "btnRetrieve"
        Me.btnRetrieve.Size = New System.Drawing.Size(96, 40)
        Me.btnRetrieve.TabIndex = 9
        Me.btnRetrieve.Text = "Retrieve"
        Me.btnRetrieve.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'btnSave
        '
        Me.btnSave.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.Image = CType(resources.GetObject("btnSave.Image"), System.Drawing.Bitmap)
        Me.btnSave.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnSave.Location = New System.Drawing.Point(336, 232)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(96, 40)
        Me.btnSave.TabIndex = 10
        Me.btnSave.Text = "Save"
        Me.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(442, 282)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnSave, Me.btnRetrieve, Me.txtAddress, Me.txtName, Me.Label3, Me.Label2, Me.lblOwnerID, Me.Label1, Me.cboOwners, Me.lblTitle, Me.grpLine})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "Form1"
        Me.Text = "All-Code-Mode"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnRetrieve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRetrieve.Click
        ' Clears DataSet of any existing data
        objDataSet.Clear()
        ' Fill schema --adds table structure information to DataSet
        ' Not essential, but handles primary keys for us,etc.
        objOwnerDA.FillSchema(objDataSet, SchemaType.Source, "Owners")
        ' Fills DataSet with info from our DataAdapter
        objOwnerDA.Fill(objDataSet, "Owners")
        ' Empty combo box
        cboOwners.Items.Clear()
        ' Loop through each row,,adding the OwnerID to combo box
        Dim i As Integer, strCurrentID As String
        For i = 1 To objDataSet.Tables("Owners").Rows.Count
            strCurrentID = objDataSet.Tables("Owners").Rows(i - 1).Item("OwnerID")
            cboOwners.Items.Add(strCurrentID)
        Next
        ' Select first item in the list
        cboOwners.SelectedIndex = 0

        FillOwnerDetails()


    End Sub

    Public Sub FillOwnerDetails()
        Dim objRow As DataRow
        objRow = objDataSet.Tables("Owners").Rows.Find(cboOwners.SelectedItem.ToString)
        lblOwnerID.Text = objRow.Item("OwnerID")
        txtName.Text = objRow.Item("Name")
        txtAddress.Text = objRow.Item("Address")
    End Sub

    Public Sub StoreOwnerDetails()
        Dim objRow As DataRow
        If lblOwnerID.Text = "" Then Exit Sub
        objRow = objDataSet.Tables("Owners").Rows.Find(lblOwnerID.Text)
        objRow.Item("Name") = txtName.Text
        objRow.Item("Address") = txtAddress.Text
    End Sub

    Private Sub cboOwners_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboOwners.SelectedIndexChanged
        StoreOwnerDetails()
        FillOwnerDetails()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        ' EXTRA NOTE: Currently, the edits you make aren't 
        ' stored until you move onto another entry.
        ' To save any edits to the current entry, before
        ' the user clicks Save, simply call the
        ' StoreOwnerDetails() routine here.

        objOwnerDA.Update(objDataSet, "Owners")

    End Sub
End Class

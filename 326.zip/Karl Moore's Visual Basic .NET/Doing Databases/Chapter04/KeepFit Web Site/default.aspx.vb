Public Class _default
    Inherits System.Web.UI.Page
    Protected WithEvents btnFind As System.Web.UI.WebControls.Button
    Protected WithEvents txtFind As System.Web.UI.WebControls.TextBox
    Protected WithEvents grdMembers As System.Web.UI.WebControls.DataGrid
    Protected WithEvents lblInfo As System.Web.UI.WebControls.Label
    Protected WithEvents lnkNewSale As System.Web.UI.WebControls.HyperLink
    Protected WithEvents lblTitle As System.Web.UI.WebControls.Label
    Protected WithEvents lblInfo2 As System.Web.UI.WebControls.Label
    Protected WithEvents lnkNewMember As System.Web.UI.WebControls.HyperLink

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub btnFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFind.Click
        ' Setup our core objects, mainly for use with our database
        Dim objConnection As New SqlClient.SqlConnection("server=.;database=KeepFit;trusted_connection=true")
        Dim objCommand As New SqlClient.SqlCommand("Select * from Members", objConnection)
        Dim objReader As SqlClient.SqlDataReader, strSQL As String

        ' Check whether the user wants to search for a particular member -
        ' if so, change the .CommandText SQL string
        If txtFind.Text <> "(All)" Then
            objCommand.CommandText = "Select * from Members where MemberID='" & txtFind.Text & "'"
        End If

        ' Open our database connection
        objConnection.Open()

        ' Get the results back into our DataReader object
        objReader = objCommand.ExecuteReader

        ' Bind our DataGrid to our DataReader object
        grdMembers.DataSource = objReader
        grdMembers.DataBind()

        ' Tell the user how many records our DataGrid is displaying
        lblInfo.Text = "Displaying " & grdMembers.Items.Count & " record(s)"

        ' Close objects
        objReader.Close()
        objConnection.Close()

    End Sub
End Class

Public Class newmember
    Inherits System.Web.UI.Page
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblInfo3 As System.Web.UI.WebControls.Label
    Protected WithEvents lblInfo2 As System.Web.UI.WebControls.Label
    Protected WithEvents lblInfo1 As System.Web.UI.WebControls.Label
    Protected WithEvents txtAddress As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtName As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblInfo4 As System.Web.UI.WebControls.Label
    Protected WithEvents txtTelNo As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnAddMember As System.Web.UI.WebControls.Button
    Protected WithEvents lblTitle As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub btnAddMember_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddMember.Click
        ' Setup the database objects
        Dim objConnection As New SqlClient.SqlConnection _
            ("server=.;database=KeepFit;trusted_connection=true")
        Dim objCommand As New SqlClient.SqlCommand("", objConnection)
        Dim objTransaction As SqlClient.SqlTransaction, strSQL As String

        Try
            ' Open connection and begin transaction
            objConnection.Open()
            objTransaction = objConnection.BeginTransaction
            ' Make the Command object aware its in this transaction
            objCommand.Transaction = objTransaction
            ' Generate SQL statement and execute to
            ' add a new Member to our Members table
            strSQL = "INSERT INTO members(name,address,telno)" & _
                "VALUES('" & txtName.Text & " ','" & txtAddress.Text & _
                "', '" & txtTelNo.Text & "')"
            objCommand.CommandText = strSQL
            objCommand.ExecuteNonQuery()
            ' Retrieve the Member ID for our new member,,the automatically
            ' generated identity value ((See Top Tip for explanation of this)
            Dim intAutoNumber As Integer
            strSQL = "SELECT @@Identity"
            objCommand.CommandText = strSQL
            intAutoNumber = objCommand.ExecuteScalar
            ' Add an initial joining fee to the Sales table
            strSQL = "INSERT INTO sales(memberid, description, charge)" & _
                "VALUES(" & intAutoNumber & ", 'Joining Fee', 25.00)"
            objCommand.CommandText = strSQL
            objCommand.ExecuteNonQuery()
            ' Commit successful transaction,,close connection
            objTransaction.Commit()
            objConnection.Close()
            ' Move back to main page
            Response.Redirect("default.aspx")
        Catch
            btnAddMember.Text = "Cannot Add Member!"
            objTransaction.Rollback()
            objConnection.Close()
        End Try
    End Sub
End Class

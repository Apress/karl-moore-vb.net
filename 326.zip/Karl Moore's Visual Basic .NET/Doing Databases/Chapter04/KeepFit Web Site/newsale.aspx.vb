Public Class newsale
    Inherits System.Web.UI.Page
    Protected WithEvents btnFind As System.Web.UI.WebControls.Button
    Protected WithEvents txtMemberID As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCharge As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblInfo4 As System.Web.UI.WebControls.Label
    Protected WithEvents lblInfo3 As System.Web.UI.WebControls.Label
    Protected WithEvents lblInfo2 As System.Web.UI.WebControls.Label
    Protected WithEvents lblInfo1 As System.Web.UI.WebControls.Label
    Protected WithEvents lblTitle As System.Web.UI.WebControls.Label
    Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub btnFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFind.Click
        ' Setup the connection
        Dim objConnection As New SqlClient.SqlConnection("server=.;database=KeepFit;trusted_connection=true")

        ' Create the final SQL string to execute - 
        ' remembering that only text strings are
        ' enclosed in "quote marks"
        Dim strSQL As String
        strSQL = "INSERT INTO sales(memberid, description, charge) " & _
            "VALUES('" & txtMemberID.Text & "', '" & _
            txtDescription.Text & "', " & txtCharge.Text & ")"

        ' Create our Command object
        Dim objCommand As New SqlClient.SqlCommand(strSQL, objConnection)

        ' Open the Connection, execute the command, close the connection
        objConnection.Open()
        objCommand.ExecuteNonQuery()
        objConnection.Close()

        ' Take user back to first page
        Response.Redirect("default.aspx")

    End Sub
End Class

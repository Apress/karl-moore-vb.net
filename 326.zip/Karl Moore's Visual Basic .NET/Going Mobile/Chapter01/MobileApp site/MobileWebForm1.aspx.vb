Public Class MobileWebForm1
    Inherits System.Web.UI.MobileControls.MobilePage
    Protected WithEvents Logon As System.Web.UI.MobileControls.Form
    Protected WithEvents Label1 As System.Web.UI.MobileControls.Label
    Protected WithEvents Label2 As System.Web.UI.MobileControls.Label
    Protected WithEvents txtUsername As System.Web.UI.MobileControls.TextBox
    Protected WithEvents cmdLogon As System.Web.UI.MobileControls.Command
    Protected WithEvents RequiredFieldValidator1 As System.Web.UI.MobileControls.RequiredFieldValidator
    Protected WithEvents Welcome As System.Web.UI.MobileControls.Form
    Protected WithEvents lblWelcome As System.Web.UI.MobileControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub cmdLogon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdLogon.Click
        If Page.IsValid = True Then
            lblWelcome.Text = "Welcome, " & txtUsername.Text & "!"
            ActiveForm = Welcome
        End If
    End Sub
End Class

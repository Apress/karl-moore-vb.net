Public Class _default
    Inherits System.Web.UI.MobileControls.MobilePage
    Protected WithEvents imgBuyStuff As System.Web.UI.MobileControls.Image
    Protected WithEvents Main As System.Web.UI.MobileControls.Form

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub Form1_Activate(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
End Class

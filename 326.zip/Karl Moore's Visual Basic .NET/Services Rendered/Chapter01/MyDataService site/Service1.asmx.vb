Imports System.Web.Services

<WebService(Namespace:="http://tempuri.org/")> _
Public Class Service1
    Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub
    Friend WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents connMyDatabase As System.Data.OleDb.OleDbConnection
    Friend WithEvents daMyDataAdapter As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents dsMyDataSet As MyDataService.MyData

    'Required by the Web Services Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand()
        Me.connMyDatabase = New System.Data.OleDb.OleDbConnection()
        Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand()
        Me.daMyDataAdapter = New System.Data.OleDb.OleDbDataAdapter()
        Me.dsMyDataSet = New MyDataService.MyData()
        CType(Me.dsMyDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'OleDbSelectCommand1
        '
        Me.OleDbSelectCommand1.CommandText = "SELECT Address, Name, OwnerID FROM Owners"
        Me.OleDbSelectCommand1.Connection = Me.connMyDatabase
        '
        'connMyDatabase
        '
        Me.connMyDatabase.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Password="""";User ID=Admin;Data Source=c:\Karl Mo" & _
        "ore's Visual Basic .NET\Doing Databases\surgery.mdb;Mode=Share Deny None;Extende" & _
        "d Properties="""";Jet OLEDB:System database="""";Jet OLEDB:Registry Path="""";Jet OLED" & _
        "B:Database Password="""";Jet OLEDB:Engine Type=5;Jet OLEDB:Database Locking Mode=1" & _
        ";Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Global Bulk Transactions=1;Jet OL" & _
        "EDB:New Database Password="""";Jet OLEDB:Create System Database=False;Jet OLEDB:En" & _
        "crypt Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Comp" & _
        "act Without Replica Repair=False;Jet OLEDB:SFP=False"
        '
        'OleDbInsertCommand1
        '
        Me.OleDbInsertCommand1.CommandText = "INSERT INTO Owners(Address, Name, OwnerID) VALUES (?, ?, ?)"
        Me.OleDbInsertCommand1.Connection = Me.connMyDatabase
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Address", System.Data.OleDb.OleDbType.VarWChar, 50, "Address"))
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Name", System.Data.OleDb.OleDbType.VarWChar, 50, "Name"))
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("OwnerID", System.Data.OleDb.OleDbType.VarWChar, 5, "OwnerID"))
        '
        'OleDbUpdateCommand1
        '
        Me.OleDbUpdateCommand1.CommandText = "UPDATE Owners SET Address = ?, Name = ?, OwnerID = ? WHERE (OwnerID = ?) AND (Add" & _
        "ress = ? OR ? IS NULL AND Address IS NULL) AND (Name = ? OR ? IS NULL AND Name I" & _
        "S NULL)"
        Me.OleDbUpdateCommand1.Connection = Me.connMyDatabase
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Address", System.Data.OleDb.OleDbType.VarWChar, 50, "Address"))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Name", System.Data.OleDb.OleDbType.VarWChar, 50, "Name"))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("OwnerID", System.Data.OleDb.OleDbType.VarWChar, 5, "OwnerID"))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_OwnerID", System.Data.OleDb.OleDbType.VarWChar, 5, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "OwnerID", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Address", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Address1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Name", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Name", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Name1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Name", System.Data.DataRowVersion.Original, Nothing))
        '
        'OleDbDeleteCommand1
        '
        Me.OleDbDeleteCommand1.CommandText = "DELETE FROM Owners WHERE (OwnerID = ?) AND (Address = ? OR ? IS NULL AND Address " & _
        "IS NULL) AND (Name = ? OR ? IS NULL AND Name IS NULL)"
        Me.OleDbDeleteCommand1.Connection = Me.connMyDatabase
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_OwnerID", System.Data.OleDb.OleDbType.VarWChar, 5, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "OwnerID", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Address", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Address1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Name", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Name", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Name1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Name", System.Data.DataRowVersion.Original, Nothing))
        '
        'daMyDataAdapter
        '
        Me.daMyDataAdapter.DeleteCommand = Me.OleDbDeleteCommand1
        Me.daMyDataAdapter.InsertCommand = Me.OleDbInsertCommand1
        Me.daMyDataAdapter.SelectCommand = Me.OleDbSelectCommand1
        Me.daMyDataAdapter.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Owners", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("OwnerID", "OwnerID"), New System.Data.Common.DataColumnMapping("Name", "Name"), New System.Data.Common.DataColumnMapping("Address", "Address")})})
        Me.daMyDataAdapter.UpdateCommand = Me.OleDbUpdateCommand1
        '
        'dsMyDataSet
        '
        Me.dsMyDataSet.DataSetName = "MyData"
        Me.dsMyDataSet.Locale = New System.Globalization.CultureInfo("en-US")
        Me.dsMyDataSet.Namespace = "http://www.tempuri.org/MyData.xsd"
        CType(Me.dsMyDataSet, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#End Region

    <WebMethod()> Public Function GetData() As MyData
        ' Passes populated Typed DataSet back to client
        daMyDataAdapter.Fill(dsMyDataSet)
        Return dsMyDataSet
    End Function

    <WebMethod()> Public Sub UpdateData(ByVal Data As MyData)
        ' Updates the backend database where needed
        daMyDataAdapter.Update(Data)
    End Sub

End Class

Module Tips

    ' Generating Random Numbers

    Dim objRandom As New System.Random(System.DateTime.Now.Ticks Mod System.Int32.MaxValue)

    Public Function GetRandomNumber(Optional ByVal Low As Integer = 1, Optional ByVal High As Integer = 100) As Integer
        ' Returns a random number,,
        ' between the optional Low and High parameters
        Return objRandom.Next(Low, High + 1)
    End Function

End Module

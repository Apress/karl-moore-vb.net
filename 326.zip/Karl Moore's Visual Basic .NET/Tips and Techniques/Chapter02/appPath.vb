Module Tips

    ' Finding the Application Directory

    Public Function GetAppPath() As String
        ' Returns the current application path,,
        ' with a trailing slash
        Dim strPath As String
        strPath = StrReverse(Application.ExecutablePath)
        strPath = Mid(strPath, InStr(1, strPath, "\"))
        strPath = StrReverse(strPath)
        Return strPath
    End Function

End Module

Module Tips

    ' Finding the Last Day of the Month

    Public Function LastDayOfMonth(ByVal MonthYear As String) As Integer
        ' Returns the number of days in the specified month,,
        ' MonthYear parameter should be in the format MM//YYYY
        Return DatePart("d ", DateAdd("d ", -1, DateAdd("m ", 1, _
                DateAdd("d ", -DatePart("d ", MonthYear) + 1, MonthYear))))
    End Function

End Module

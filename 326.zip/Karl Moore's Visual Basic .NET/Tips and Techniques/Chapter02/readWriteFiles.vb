Module Tips

    ' Reading and Writing to Files

    Public Function ReadTextFromFile(ByVal Filename As String) As String
        ' Returns text from the specified file
        On Error Resume Next
        Dim strFileText As String
        ' Open the file and launch StreamReader object
        Dim MyReader As System.IO.StreamReader = System.IO.File.OpenText(Filename)
        ' Read all text through to the end
        strFileText = MyReader.ReadToEnd
        ' Close the stream
        MyReader.Close()
        ' Return data
        Return strFileText
    End Function

    Public Sub WriteTextToFile(ByVal Filename As String, ByVal Text As String)
        ' Writes the passed Text into the specified file
        ' Create file and StreamWriter object
        Dim MyWriter As System.IO.StreamWriter = System.IO.File.CreateText(Filename)
        ' Write text to the stream
        MyWriter.Write(Text)
        ' Close the stream
        MyWriter.Close()
    End Sub



End Module

Module Tips

    ' Reading an XML file example

    Public Sub ReadXMLFile()
        ' Open XML for reading from file or URL
        Dim MyReader As New Xml.XmlTextReader("c:\simple.xml")
        Dim strOutput As String, intCount As Integer
        ' Read each node of the XML document
        Do While MyReader.Read
            ' Check the node type
            Select Case MyReader.NodeType
                ' If the start of an element ....
            Case Xml.XmlNodeType.Element
                    strOutput += "<" & MyReader.Name
                    ' Read the attributes
                    If MyReader.HasAttributes Then
                        For intCount = 0 To MyReader.AttributeCount - 1
                            MyReader.MoveToAttribute(intCount)
                            strOutput += " " & MyReader.Name & "=" & MyReader.Value
                        Next
                    End If
                    strOutput += ">"
                    ' If this is an elements' text ....
                Case Xml.XmlNodeType.Text
                    strOutput += MyReader.Value
                    ' If this is the end of an element ....
                Case Xml.XmlNodeType.EndElement
                    strOutput += "</" & MyReader.Name & ">"
            End Select
        Loop
    End Sub

End Module

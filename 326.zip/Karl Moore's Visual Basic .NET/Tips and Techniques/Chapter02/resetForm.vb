Module Tips

    ' Resetting a Form

    Public Sub ResetForm(ByVal FormToReset As Form)
        ' Resets the main data entry controls on the passed FormToReset
        Dim objControl As Control
        ' Loop round every control on the form
        For Each objControl In FormToReset.Controls
            ' Check we don �t need to skip this control
            If InStr(objControl.Tag, "skip ", CompareMethod.Text) = 0 Then
                If TypeOf (objControl) Is System.Windows.Forms.TextBox Then
                    objControl.Text = "" ' Clear TextBox
                ElseIf TypeOf (objControl) Is System.Windows.Forms.CheckBox Then
                    Dim objCheckBox As System.Windows.Forms.CheckBox = objControl
                    objCheckBox.Checked = False ' Uncheck CheckBox
                ElseIf TypeOf (objControl) Is System.Windows.Forms.ComboBox Then
                    Dim objComboBox As System.Windows.Forms.ComboBox = objControl
                    objComboBox.SelectedIndex = -1 ' Deselect any ComboBox entry
                End If
            End If
        Next
    End Sub

End Module

Module Tips

    ' Validating an Email Address

    Public Function IsEmailAddress(ByVal EmailAddress As String, _
        Optional ByRef RejectReason As String = "") As Boolean
        ' Returns a True if the passed EmailAddress is valid,,
        ' otherwise returns a False plus passes the reject
        ' reason back to the RejectReason argument
        Dim strPrefix As String
        Dim strSuffix As String
        Dim strMiddle As String
        Dim intCharCount As Integer
        Dim strBuffer As String
        ' Trim excess spacing
        EmailAddress = Trim(EmailAddress)
        ' Reject short addresses
        If Len(EmailAddress) < 8 Then
            RejectReason = "Your address is too short"
            Return False
        End If
        ' Reject addresses with no @sign
        If InStr(EmailAddress, "@") = 0 Then
            RejectReason = "Your address doesn�t contain the @ sign"
            Return False
        End If
        ' Reject addresses with too many @signs
        If InStr(InStr(EmailAddress, "@") + 1, EmailAddress, "@") <> 0 Then
            RejectReason = "Your address contains too many @signs"
            Return False
        End If
        ' Reject addresses without a period
        If InStr(EmailAddress, ".") = 0 Then
            RejectReason = "Your address doesn �t contain a period"
            Return False
        End If
        ' Check ordering and length formatting
        If InStr(EmailAddress, "@") = 1 Or InStr(EmailAddress, "@") = _
            Len(EmailAddress) Or InStr(EmailAddress, ".") = 1 Or _
            InStr(EmailAddress, ".") = Len(EmailAddress) Then
            RejectReason = "Your address is badly formatted "
            Return False
        End If
        ' Check for invalid characters
        For intCharCount = 1 To Len(EmailAddress)
            strBuffer = Mid(EmailAddress, intCharCount, 1)
            If Not (LCase(strBuffer) Like "[a-z ]" Or strBuffer = "@" Or _
                strBuffer = "." Or strBuffer = "-" Or strBuffer = "_" Or _
                IsNumeric(strBuffer)) Then
                RejectReason = "Your address contains invalid characters "
                Return False
            End If
        Next
        ' Check length of suffix
        strBuffer = Microsoft.VisualBasic.Right(EmailAddress, 4)
        If InStr(strBuffer, ".") = 0 Then
            If Len(strBuffer) > 4 Then
                RejectReason = "Your address suffix is too long"
                Return False
            Else
                RejectReason = Nothing
                Return True
            End If
        End If
        ' Retrieve and check length of suffix
        If Microsoft.VisualBasic.Left(strBuffer, 1) = "." Then _
            strBuffer = Microsoft.VisualBasic.Right(strBuffer, 3)
        If Microsoft.VisualBasic.Left(Microsoft.VisualBasic.Right( _
            strBuffer, 3), 1) = "." Then strBuffer = _
            Microsoft.VisualBasic.Right(strBuffer, 2)
        If Microsoft.VisualBasic.Left(Microsoft.VisualBasic.Right( _
            strBuffer, 2), 1) = "." Then strBuffer = _
            Microsoft.VisualBasic.Right(strBuffer, 1)
        If Len(strBuffer) < 2 Then
            RejectReason = "Your address suffix is too short "
            Return False
        End If
        ' Otherwise, success!
        RejectReason = Nothing
        Return True
    End Function

End Module

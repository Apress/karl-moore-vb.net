' Encrypting a file

Imports System.Security.Cryptography
' You must first �import� the System..Security.Cryptography
' namespace, either via the Project Properties
' or by placing this Imports statement above your class/module

Module Tips

    Public Function GenerateKey() As Byte()
        ' Returns a random key to use
        Dim objDES As New System.Security.Cryptography.DESCryptoServiceProvider()
        objDES.GenerateKey()
        Return objDES.Key
    End Function

    Public Function GenerateIV() As Byte()
        ' Returns a random IV to use
        Dim objDES As New System.Security.Cryptography.DESCryptoServiceProvider()
        objDES.GenerateIV()
        Return objDES.IV
    End Function

    Public Sub SaveEncryptedFile(ByVal Key() As Byte, ByVal IV() As Byte, _
        ByVal Data As String, ByVal Filename As String)

        ' Create new file stream
        Dim objFileStream As New System.IO.FileStream(Filename, _
            System.IO.FileMode.Create, System.IO.FileAccess.Write)
        ' Convert data to byte array
        Dim bytInput As Byte() = New _
        System.Text.UnicodeEncoding().GetBytes(Data)
        ' Create new DES instance
        Dim objDES As New DESCryptoServiceProvider()
        ' Sets Key and Initialization Vector
        objDES.Key = Key
        objDES.IV = IV

        ' Create a DES encrypter from this object
        Dim objDESEncrypt As ICryptoTransform = objDES.CreateEncryptor()
        ' Create a CyptoStream object that encrypts stream using DES
        Dim objCryptStream As New CryptoStream(objFileStream, _
            objDESEncrypt, CryptoStreamMode.Write)
        ' Write to DES-encrypted file
        objCryptStream.Write(bytInput, 0, bytInput.Length)
        ' Close streams
        objCryptStream.Close()
        objFileStream.Close()

    End Sub

    Public Function LoadEncryptedFile(ByVal Key() As Byte, _
        ByVal IV() As Byte, ByVal Filename As String) As String

        ' Create new file stream
        Dim objFileStream As New System.IO.FileStream(Filename, _
            System.IO.FileMode.Open, System.IO.FileAccess.Read)
        ' Create DES decryptor
        Dim objDES As New DESCryptoServiceProvider()
        ' Sets Key and Initialization Vector
        objDES.Key = Key
        objDES.IV = IV

        ' Create a DES decryptor from this object
        Dim objDESDecrypt As ICryptoTransform = objDES.CreateDecryptor()
        ' Create a CryptoStream object to read and DES decrypt incoming bytes
        Dim objCryptStream As New CryptoStream(objFileStream, objDESDecrypt, _
            CryptoStreamMode.Read)
        ' Return decrypted results
        LoadEncryptedFile = New System.IO.StreamReader(objCryptStream, _
            New System.Text.UnicodeEncoding()).ReadToEnd()
        ' Close streams
        objCryptStream.Close()
        objFileStream.Close()

    End Function

End Module

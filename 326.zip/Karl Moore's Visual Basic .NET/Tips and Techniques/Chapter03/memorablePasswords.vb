Module Tips

    ' Generating Memorable Passwords

    Dim objRandom As New System.Random(System.DateTime.Now.Ticks _
        Mod System.Int32.MaxValue)

    Public Function GeneratePassword(ByVal Length As Integer) As String
        ' Creates a memorable password of the specified Length
        Dim blnOnVowel As Boolean
        Dim strTempLetter As String
        Dim strPassword As String
        Dim intCount As Integer
        For intCount = 1 To Length
            If blnOnVowel = False Then
                ' Choose a nice consonant --no C, X, Z, or Q
                strTempLetter = Choose(GetRandomNumber(1, 17), _
                "B", "D", "F", "G", "H", "J", "K", "L", "M", _
                "N", "P", "R", "S", "T", "V", "W", "Y")
                ' Append it to the password string
                strPassword += strTempLetter
                ' Swich to vowel mode
                blnOnVowel = True
            Else
                ' Choose a vowel
                strTempLetter = Choose(GetRandomNumber(1, 5), _
                    "A", "E", "I", "O", "U")
                ' Append it to the password string
                strPassword += strTempLetter
                ' Switch back again, ready for next loop round
                blnOnVowel = False
            End If
        Next
        Return strPassword
    End Function

    Public Function GetRandomNumber(Optional ByVal Low As Integer = 1, _
        Optional ByVal High As Integer = 100) As Integer
        ' Returns a random number,
        ' between the optional Low and High parameters
        Return objRandom.Next(Low, High + 1)
    End Function

End Module

Module Tips

    ' Checking for a Previous Instance

    Public Function PrevInstance() As Boolean
        If UBound(Diagnostics.Process.GetProcessesByName _
        (Diagnostics.Process.GetCurrentProcess.ProcessName)) > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

End Module

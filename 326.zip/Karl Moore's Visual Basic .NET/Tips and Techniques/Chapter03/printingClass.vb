' Printing from your Program

Public Class TextFilePrint
    ' Inherits all the functionality of a PrintDocument
    Inherits Printing.PrintDocument
    ' Private variables to hold default font and stream
    Private fntPrintFont As Font
    Private objStream As IO.StreamReader
    Public Sub New(ByVal FileStream As IO.StreamReader)
        ' Sets the file stream
        MyBase.New()
        Me.objStream = FileStream
    End Sub
    Protected Overrides Sub OnBeginPrint(ByVal ev As Printing.PrintEventArgs)
        ' Sets the default font
        MyBase.OnBeginPrint(ev)
        fntPrintFont = New Font("Times New Roman ", 12)
    End Sub

    Public Property Font() As Font
        ' Allows the user to override the default font
        Get
            Return fntPrintFont
        End Get
        Set(ByVal Value As Font)
            fntPrintFont = Value
        End Set
    End Property
    Protected Overrides Sub OnPrintPage(ByVal ev As Printing.PrintPageEventArgs)
        ' Provides the print logic for our document
        MyBase.OnPrintPage(ev)
        Dim sngLinesPerPage As Single = 0
        Dim yPos As Single = 0
        Dim intCount As Integer = 0
        Dim sglLeftMargin As Single = ev.MarginBounds.Left
        Dim sglTopMargin As Single = ev.MarginBounds.Top
        Dim strLine As String
        ' Calculate number of lines per page,,using MarginBounds
        sngLinesPerPage = ev.MarginBounds.Height / _
        fntPrintFont.GetHeight(ev.Graphics)
        ' Read a line from our file stream
        strLine = objStream.ReadLine()
        ' Loop around while we have data in our line
        ' and our counter is less than the number of lines per page
        While (intCount < sngLinesPerPage And Not (strLine Is Nothing))
            ' Position our line
            yPos = sglTopMargin + (intCount * fntPrintFont.GetHeight(ev.Graphics))
            ' Draw our text onto the print document
            ev.Graphics.DrawString(strLine, fntPrintFont, _
                Brushes.Black, sglLeftMargin, yPos, New StringFormat())
            ' Increment the counter
            intCount += 1

            ' If the counter is less than the number of lines per page,,
            ' read in another line from our file stream
            If (intCount < sngLinesPerPage) Then
                strLine = objStream.ReadLine()
            End If
        End While
        ' If we still have data remaining,,go print another page
        If Not (strLine Is Nothing) Then
            ev.HasMorePages = True
        Else
            ev.HasMorePages = False
        End If
    End Sub
End Class
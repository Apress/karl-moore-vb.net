Module Tips

    ' Using Simple Encryption

    Public Function Crypt(ByVal Text As String) As String
        ' Encrypts or decrypts the passed Text
        Dim strTempChar As String, i As Integer
        For i = 1 To Len(Text)
            If Asc(Mid(Text, i, 1)) < 128 Then
                strTempChar = Asc(Mid(Text, i, 1)) + 128
            ElseIf Asc(Mid(Text, i, 1)) > 128 Then
                strTempChar = Asc(Mid(Text, i, 1)) - 128
            End If
            Mid(Text, i, 1) = Chr(strTempChar)
        Next
        Return Text
    End Function

End Module

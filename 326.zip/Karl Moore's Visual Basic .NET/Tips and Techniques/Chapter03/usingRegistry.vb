Module Tips

    ' Saving to the Registry

    Public Function ReadFromRegistry(ByVal Location As String, ByVal Name As String)
        ' Returns a value from the registry
        Dim MyKey As Microsoft.Win32.RegistryKey
        MyKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(Location)
        ReadFromRegistry = MyKey.GetValue(Name)
        MyKey.Close()
    End Function

    Public Sub WriteToRegistry(ByVal Location As String, _
        ByVal Name As String, ByVal Data As String)
        ' Writes a value to the registry
        Dim MyKey As Microsoft.Win32.RegistryKey
        MyKey = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(Location)
        MyKey.SetValue(Name, Data)
        MyKey.Close()
    End Sub

End Module

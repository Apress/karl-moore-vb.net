Module Tips

    ' Checking for a Whole Number

    Public Function IsWholeNumber(ByVal Number As Object) As Boolean
        ' Accepts a number and returns True of False
        ' Raise error is Number is not number
        If Not IsNumeric(Number) Then Throw New System.ArgumentOutOfRangeException()
        ' Return a True if Number minus integer version of number equals zero
        Return (Number - CInt(Number)) = 0
    End Function

End Module

Public Class CDog

    Public Name As String
    Private shtAge As Short
    Private udtCoat As CoatType

    Public Enum CoatType As Short
        BigAndShaggy = 1
        ShortCrewCut = 2
        PoodleStyleAfro = 3
        Unknown = 4
    End Enum

    Private shtCoatType As CoatType

    Public Event Awake()

    Public Sub Sleep()

        Dim intCount As Integer

        For intCount = 1 To 1000000
            Application.DoEvents()
        Next

        RaiseEvent Awake()

    End Sub

    Public Property Coat() As CoatType
        Get
            Return shtCoatType
        End Get
        Set(ByVal Value As CoatType)
            shtCoatType = Value
        End Set
    End Property

    Public Property Age() As Short
        Get
            Return shtAge
        End Get
        Set(ByVal Value As Short)
            If Value < 20 Then shtAge = Value
        End Set
    End Property

    Public Sub Bark()
        MessageBox.Show("Woof! Woof!")
    End Sub

    Public Function Feed(ByVal FoodName As String) As String

        If FoodName = "PASTA" Then
            Return "Yuck! Take it back."
        ElseIf FoodName = "BOUNCERS" Then
            Return "Hmm, my favourite. Please sir, more..."
        Else
            Return "Woof! Thanks for the " & FoodName
        End If

    End Function

    Public Sub New()
        ' Constructor
    End Sub

    Protected Overrides Sub Finalize()
        ' Finalizer
        MyBase.Finalize()
    End Sub

End Class

Public Class Customer
    Public CustomerID As String
    Public Name As String
    Public Address As String
End Class

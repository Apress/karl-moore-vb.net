Public Class Customers

    Private mcolCustomers As New Collection()

    ' Adds a customer to our collection
    Public Sub Add(ByVal Customer As Customer, ByVal Key As String)
        mcolCustomers.Add(Customer, Key)
    End Sub

    ' Returns the number of Customer objects in our collection
    Public ReadOnly Property Count() As Integer
        Get
            Return mcolCustomers.Count
        End Get
    End Property

    ' Returns a Customer object from our collection
    Public ReadOnly Property Item(ByVal IndexOrKey As Object) As Customer
        Get
            Return mcolCustomers.Item(IndexOrKey)
        End Get
    End Property

    ' Removes a Customer object from our collection
    Public Sub Remove(ByVal IndexOrKey As Object)
        mcolCustomers.Remove(IndexOrKey)
    End Sub



End Class

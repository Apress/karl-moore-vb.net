// Important Note //

To use these Web files, you will need to setup this folder as an IIS virtual directory (preferably called "appointment").

To do this, first launch the Internet Services Manager (Start, Programs, Administrative Tools, Internet Services Manager - or Internet Information Services in Windows XP). Branch out the nodes until you reach "Default Web Site". Right-click and select New, Virtual Directory - click Next at the introduction, enter the site name ("appointment"), click Next, specify the path to this folder, click Next, Next again, then Finish.

To open the source code files, just open the Solution (.SLN) or Project (.VBPROJ) files within the folder. Alternatively, run the site by visiting it at http://localhost/appointment/
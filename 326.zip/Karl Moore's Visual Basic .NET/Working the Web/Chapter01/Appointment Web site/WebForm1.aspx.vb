Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents txtName As System.Web.UI.WebControls.TextBox
    Protected WithEvents calDate As System.Web.UI.WebControls.Calendar
    Protected WithEvents txtTime As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblInformation As System.Web.UI.WebControls.Label
    Protected WithEvents btnMakeAppointment As System.Web.UI.WebControls.Button
    Protected WithEvents txtTelephoneNum As System.Web.UI.WebControls.TextBox

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        txtTime.Text = "09:00"
    End Sub

    Private Sub btnMakeAppointment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMakeAppointment.Click
        lblInformation.Text = "Thank you, " & txtName.Text & ". " & _
            "Your appointment has been booked for " & _
            calDate.SelectedDate & " at " & txtTime.Text & ". " & _
            "Be there... or be ill!"
    End Sub
End Class

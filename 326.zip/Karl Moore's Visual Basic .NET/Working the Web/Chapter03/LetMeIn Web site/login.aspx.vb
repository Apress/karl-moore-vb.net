Imports System.Web.Security

Public Class login
    Inherits System.Web.UI.Page
    Protected WithEvents txtUsername As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
    Protected WithEvents chkPersist As System.Web.UI.WebControls.CheckBox
    Protected WithEvents btnLogin As System.Web.UI.WebControls.Button
    Protected WithEvents lblPassword As System.Web.UI.WebControls.Label
    Protected WithEvents lblTitle2 As System.Web.UI.WebControls.Label
    Protected WithEvents lblTitle1 As System.Web.UI.WebControls.Label
    Protected WithEvents pnlLogin As System.Web.UI.WebControls.Panel
    Protected WithEvents lblUsername As System.Web.UI.WebControls.Label
    Protected WithEvents lblInfo As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        If FormsAuthentication.Authenticate(txtUsername.Text, txtPassword.Text) = True Then
            FormsAuthentication.RedirectFromLoginPage(txtUsername.Text, chkPersist.Checked)
        Else
            lblInfo.Text = "Invalid credentials - please try again, you hacker type, you!"
        End If

    End Sub
End Class
